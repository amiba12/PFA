import React, { useState, useEffect } from 'react';
import {
  PiggyBank,
  DollarSign,
  TrendingUp,
  BookOpen,
  LayoutDashboard,
  PlusCircle,
  ListOrdered,
  Settings,
  Target,
  BookOpenCheck,
  Bell,
  BarChart as ChartBar
} from 'lucide-react';
import { Line, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

type Expense = {
  id: string;
  amount: number;
  description: string;
  category: string;
  date: string;
};

type SavingsGoal = {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  contributions: {
    date: string;
    amount: number;
  }[];
};

type View = 'dashboard' | 'add' | 'list' | 'settings' | 'goals' | 'education' | 'analytics';

type FinancialTip = {
  id: string;
  title: string;
  content: string;
  category: string;
};

const TIPS: FinancialTip[] = [
  {
    id: '1',
    title: 'La règle des 50/30/20',
    content: 'Essayez de diviser votre budget mensuel ainsi : 50% pour les besoins essentiels, 30% pour les envies, et 20% pour l\'épargne.',
    category: 'budgeting'
  },
  {
    id: '2',
    title: 'Épargne automatique',
    content: 'Mettez en place un virement automatique vers votre compte d\'épargne dès réception de votre salaire.',
    category: 'saving'
  },
  {
    id: '3',
    title: 'Suivi des dépenses',
    content: 'Notez toutes vos dépenses pendant un mois pour identifier les domaines où vous pourriez économiser.',
    category: 'tracking'
  }
];

const AVERAGE_EXPENSES = {
  groceries: 400,
  transportation: 200,
  entertainment: 150,
  utilities: 300,
  other: 200
};

function App() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('groceries');
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([]);
  const [newGoal, setNewGoal] = useState({
    name: '',
    targetAmount: '',
    deadline: ''
  });
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
  const [contributionAmount, setContributionAmount] = useState('');

  const categories = [
    'groceries',
    'transportation',
    'entertainment',
    'utilities',
    'other'
  ];

  useEffect(() => {
    if (description.toLowerCase().includes('grocery') || description.toLowerCase().includes('food')) {
      setCategory('groceries');
    } else if (description.toLowerCase().includes('bus') || description.toLowerCase().includes('train')) {
      setCategory('transportation');
    } else if (description.toLowerCase().includes('movie') || description.toLowerCase().includes('concert')) {
      setCategory('entertainment');
    } else if (description.toLowerCase().includes('electricity') || description.toLowerCase().includes('water')) {
      setCategory('utilities');
    }
  }, [description]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newExpense: Expense = {
      id: crypto.randomUUID(),
      amount: parseFloat(amount),
      description,
      category,
      date: new Date().toISOString(),
    };
    setExpenses([...expenses, newExpense]);
    setAmount('');
    setDescription('');

    const categoryTotal = expenses
      .filter(exp => exp.category === category)
      .reduce((sum, exp) => sum + exp.amount, 0) + parseFloat(amount);
    
    if (categoryTotal > AVERAGE_EXPENSES[category as keyof typeof AVERAGE_EXPENSES]) {
      alert(`Attention : Vos dépenses en ${category} dépassent la moyenne habituelle !`);
    }
  };

  const calculateSavingsNeeded = (goal: SavingsGoal) => {
    const today = new Date();
    const deadline = new Date(goal.deadline);
    const remainingAmount = goal.targetAmount - goal.currentAmount;
    
    // Calculer le nombre de mois restants
    const monthsRemaining = (deadline.getFullYear() - today.getFullYear()) * 12 + 
      (deadline.getMonth() - today.getMonth());
    
    // Calculer le nombre de semaines restantes
    const weeksRemaining = Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24 * 7));
    
    return {
      monthly: remainingAmount / monthsRemaining,
      weekly: remainingAmount / weeksRemaining
    };
  };

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const goal: SavingsGoal = {
      id: crypto.randomUUID(),
      name: newGoal.name,
      targetAmount: parseFloat(newGoal.targetAmount),
      currentAmount: 0,
      deadline: newGoal.deadline,
      contributions: []
    };
    setSavingsGoals([...savingsGoals, goal]);
    setNewGoal({ name: '', targetAmount: '', deadline: '' });
  };

  const handleContribution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGoalId || !contributionAmount) return;

    setSavingsGoals(goals => goals.map(goal => {
      if (goal.id === selectedGoalId) {
        const newAmount = goal.currentAmount + parseFloat(contributionAmount);
        return {
          ...goal,
          currentAmount: newAmount,
          contributions: [
            ...goal.contributions,
            { date: new Date().toISOString(), amount: parseFloat(contributionAmount) }
          ]
        };
      }
      return goal;
    }));

    setContributionAmount('');
    setSelectedGoalId(null);
  };

  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);

  const expensesByCategory = categories.map(cat => ({
    category: cat,
    amount: expenses
      .filter(exp => exp.category === cat)
      .reduce((sum, exp) => sum + exp.amount, 0)
  }));

  const monthlyData = {
    labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'],
    datasets: [
      {
        label: 'Dépenses mensuelles',
        data: [totalExpenses, 0, 0, 0, 0, 0],
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }
    ]
  };

  const categoryData = {
    labels: categories,
    datasets: [{
      data: expensesByCategory.map(cat => cat.amount),
      backgroundColor: [
        'rgba(255, 99, 132, 0.5)',
        'rgba(54, 162, 235, 0.5)',
        'rgba(255, 206, 86, 0.5)',
        'rgba(75, 192, 192, 0.5)',
        'rgba(153, 102, 255, 0.5)'
      ]
    }]
  };

  const NavLink = ({ icon: Icon, label, view }: { icon: any; label: string; view: View }) => (
    <button
      onClick={() => setCurrentView(view)}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg w-full ${
        currentView === view 
          ? 'bg-indigo-100 text-indigo-700' 
          : 'text-gray-600 hover:bg-gray-100'
      }`}
    >
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <PiggyBank className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">TrackEase</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar */}
          <div className="col-span-12 md:col-span-3 lg:col-span-2">
            <div className="bg-white rounded-lg shadow p-4 space-y-2">
              <NavLink icon={LayoutDashboard} label="Tableau de bord" view="dashboard" />
              <NavLink icon={PlusCircle} label="Ajouter une dépense" view="add" />
              <NavLink icon={ListOrdered} label="Liste des dépenses" view="list" />
              <NavLink icon={Target} label="Objectifs d'épargne" view="goals" />
              <NavLink icon={ChartBar} label="Analyses" view="analytics" />
              <NavLink icon={BookOpenCheck} label="Conseils" view="education" />
              <NavLink icon={Settings} label="Paramètres" view="settings" />
            </div>
          </div>

          {/* Main Content */}
          <div className="col-span-12 md:col-span-9 lg:col-span-10 space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <DollarSign className="h-8 w-8 text-green-500" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Dépenses totales</p>
                    <p className="text-2xl font-semibold text-gray-900">${totalExpenses.toFixed(2)}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <TrendingUp className="h-8 w-8 text-blue-500" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Ce mois</p>
                    <p className="text-2xl font-semibold text-gray-900">${totalExpenses.toFixed(2)}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <BookOpen className="h-8 w-8 text-purple-500" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">Catégories</p>
                    <p className="text-2xl font-semibold text-gray-900">{categories.length}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Main View Content */}
            {currentView === 'dashboard' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Dépenses par catégorie</h2>
                  <div className="h-64">
                    <Doughnut data={categoryData} options={{ maintainAspectRatio: false }} />
                  </div>
                </div>
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Activité récente</h2>
                  <div className="space-y-4">
                    {expenses.slice(0, 5).map((expense) => (
                      <div
                        key={expense.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <p className="font-medium text-gray-900">{expense.description}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(expense.date).toLocaleDateString()} • {expense.category}
                          </p>
                        </div>
                        <span className="font-semibold text-gray-900">
                          ${expense.amount.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {currentView === 'add' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Ajouter une dépense</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="amount" className="block text-sm font-medium text-gray-700">
                      Montant (€)
                    </label>
                    <input
                      type="number"
                      id="amount"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                      placeholder="0.00"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <input
                      type="text"
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                      placeholder="Courses alimentaires"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                      Catégorie
                    </label>
                    <select
                      id="category"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                    >
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat.charAt(0).toUpperCase() + cat.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    Ajouter la dépense
                  </button>
                </form>
              </div>
            )}

            {currentView === 'list' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Toutes les dépenses</h2>
                <div className="space-y-4">
                  {expenses.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">Aucune dépense enregistrée</p>
                  ) : (
                    expenses.map((expense) => (
                      <div
                        key={expense.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <p className="font-medium text-gray-900">{expense.description}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(expense.date).toLocaleDateString()} • {expense.category}
                          </p>
                        </div>
                        <span className="font-semibold text-gray-900">
                          ${expense.amount.toFixed(2)}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {currentView === 'goals' && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Ajouter un objectif d'épargne</h2>
                  <form onSubmit={handleAddGoal} className="space-y-4">
                    <div>
                      <label htmlFor="goalName" className="block text-sm font-medium text-gray-700">
                        Nom de l'objectif
                      </label>
                      <input
                        type="text"
                        id="goalName"
                        value={newGoal.name}
                        onChange={(e) => setNewGoal({...newGoal, name: e.target.value})}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="targetAmount" className="block text-sm font-medium text-gray-700">
                        Montant cible (€)
                      </label>
                      <input
                        type="number"
                        id="targetAmount"
                        value={newGoal.targetAmount}
                        onChange={(e) => setNewGoal({...newGoal, targetAmount: e.target.value})}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="deadline" className="block text-sm font-medium text-gray-700">
                        Date limite
                      </label>
                      <input
                        type="date"
                        id="deadline"
                        value={newGoal.deadline}
                        onChange={(e) => setNewGoal({...newGoal, deadline: e.target.value})}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                      Ajouter l'objectif
                    </button>
                  </form>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Ajouter une épargne</h2>
                  <form onSubmit={handleContribution} className="space-y-4">
                    <div>
                      <label htmlFor="goalSelect" className="block text-sm font-medium text-gray-700">
                        Sélectionner un objectif
                      </label>
                      <select
                        id="goalSelect"
                        value={selectedGoalId || ''}
                        onChange={(e) => setSelectedGoalId(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        required
                      >
                        <option value="">Sélectionner un objectif</option>
                        {savingsGoals.map((goal) => (
                          <option key={goal.id} value={goal.id}>
                            {goal.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label htmlFor="contributionAmount" className="block text-sm font-medium text-gray-700">
                        Montant de l'épargne (€)
                      </label>
                      <input
                        type="number"
                        id="contributionAmount"
                        value={contributionAmount}
                        onChange={(e) => setContributionAmount(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                      Ajouter l'épargne
                    </button>
                  </form>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Mes objectifs d'épargne</h2>
                  <div className="space-y-6">
                    {savingsGoals.map((goal) => {
                      const savingsNeeded = calculateSavingsNeeded(goal);
                      return (
                        <div key={goal.id} className="bg-gray-50 rounded-lg p-6">
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="font-medium text-gray-900">{goal.name}</h3>
                            <span className="text-sm text-gray-500">
                              Échéance : {new Date(goal.deadline).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                            <div
                              className="bg-indigo-600 h-2.5 rounded-full"
                              style={{ width: `${(goal.currentAmount / goal.targetAmount) * 100}%` }}
                            ></div>
                          </div>
                          <div className="flex justify-between mb-4 text-sm">
                            <span>{((goal.currentAmount / goal.targetAmount) * 100).toFixed(1)}%</span>
                            <span>{goal.currentAmount}€ / {goal.targetAmount}€</span>
                          </div>
                          <div className="bg-blue-50 p-4 rounded-lg">
                            <h4 className="font-medium text-blue-900 mb-2">Plan d'épargne suggéré</h4>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <p className="text-sm text-blue-700">Épargne mensuelle</p>
                                <p className="font-semibold text-blue-900">{savingsNeeded.monthly.toFixed(2)}€</p>
                              </div>
                              <div>
                                <p className="text-sm text-blue-700">Épargne hebdomadaire</p>
                                <p className="font-semibold text-blue-900">{savingsNeeded.weekly.toFixed(2)}€</p>
                              </div>
                            </div>
                          </div>
                          {goal.contributions.length > 0 && (
                            <div className="mt-4">
                              <h4 className="font-medium text-gray-900 mb-2">Historique des versements</h4>
                              <div className="space-y-2">
                                {goal.contributions.map((contribution, index) => (
                                  <div key={index} className="flex justify-between text-sm">
                                    <span>{new Date(contribution.date).toLocaleDateString()}</span>
                                    <span className="font-medium">+{contribution.amount}€</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {currentView === 'analytics' && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Évolution des dépenses</h2>
                  <div className="h-64">
                    <Line data={monthlyData} options={{ maintainAspectRatio: false }} />
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Comparaison avec la moyenne</h2>
                  <div className="space-y-4">
                    {categories.map((cat) => {
                      const userAmount = expensesByCategory.find(e => e.category === cat)?.amount || 0;
                      const avgAmount = AVERAGE_EXPENSES[cat as keyof typeof AVERAGE_EXPENSES];
                      const difference = userAmount - avgAmount;
                      const percentDiff = (difference / avgAmount) * 100;

                      return (
                        <div key={cat} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="capitalize">{cat}</span>
                            <span className={`font-medium ${difference > 0 ? 'text-red-500' : 'text-green-500'}`}>
                              {difference > 0 ? '+' : ''}{percentDiff.toFixed(1)}%
                            </span>
                          </div>
                          <div className="flex space-x-2 items-center">
                            <div className="flex-grow h-2 bg-gray-200 rounded-full">
                              <div
                                className={`h-2 rounded-full ${difference > 0 ? 'bg-red-500' : 'bg-green-500'}`}
                                style={{ width: `${Math.min(Math.abs(percentDiff), 100)}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-gray-500">
                              {userAmount.toFixed(0)}€ vs {avgAmount}€
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {currentView === 'education' && (
              <div className="space-y-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Conseils financiers</h2>
                  <div className="grid gap-6 md:grid-cols-2">
                    {TIPS.map((tip) => (
                      <div key={tip.id} className="bg-gray-50 rounded-lg p-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-2">{tip.title}</h3>
                        <p className="text-gray-600">{tip.content}</p>
                        <span className="inline-block mt-4 text-sm text-indigo-600 capitalize">
                          {tip.category}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Conseils personnalisés</h2>
                  <div className="space-y-4">
                    {expensesByCategory.map(({ category, amount }) => {
                      const avgAmount = AVERAGE_EXPENSES[category as keyof typeof AVERAGE_EXPENSES];
                      if (amount > avgAmount) {
                        return (
                          <div key={category} className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                            <div className="flex">
                              <div className="flex-shrink-0">
                                <Bell className="h-5 w-5 text-yellow-400" />
                              </div>
                              <div className="ml-3">
                                <p className="text-sm text-yellow-700">
                                  Vos dépenses en <strong className="capitalize">{category}</strong>sont supérieures à la moyenne.
                                  Essayez de réduire ces dépenses pour atteindre l'objectif de {avgAmount}€.
                                </p>
                              </div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    })}
                  </div>
                </div>
              </div>
            )}

            {currentView === 'settings' && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Paramètres</h2>
                <p className="text-gray-600">Page des paramètres à venir...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;