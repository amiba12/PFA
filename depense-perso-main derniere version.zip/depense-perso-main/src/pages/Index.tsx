
import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Settings as SettingsIcon, User, Bell, Lock, Camera, Fingerprint } from 'lucide-react';
import { useExpenseStore } from '@/store/useExpenseStore';

const Settings = () => {
  const [currency, setCurrency] = useState('EUR');
  const [darkMode, setDarkMode] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [budgetAlerts, setBudgetAlerts] = useState(true);
  const [goalReminders, setGoalReminders] = useState(true);
  const [useFaceID, setUseFaceID] = useState(false);
  const { currentUser } = useExpenseStore();
  
  // Initialize darkMode from localStorage or system preference
  useEffect(() => {
    // Check if user has a saved preference
    const savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode !== null) {
      setDarkMode(savedDarkMode === 'true');
      document.documentElement.classList.toggle('dark', savedDarkMode === 'true');
    } else {
      // Check system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setDarkMode(prefersDark);
      document.documentElement.classList.toggle('dark', prefersDark);
    }
    
    // Check Face ID status for current user
    if (currentUser) {
      const hasFaceID = localStorage.getItem(`faceID_${currentUser.username}`) === 'true';
      setUseFaceID(hasFaceID);
    }
  }, [currentUser]);
  
  // Update darkMode when the toggle is changed
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    localStorage.setItem('darkMode', darkMode.toString());
  }, [darkMode]);
  
  const handleSaveProfile = () => {
    toast({
      title: "Profil mis à jour",
      description: "Vos informations personnelles ont été mises à jour avec succès.",
    });
  };
  
  const handleSavePreferences = () => {
    toast({
      title: "Préférences mises à jour",
      description: "Vos préférences d'affichage ont été mises à jour avec succès.",
    });
  };
  
  const handleSaveNotifications = () => {
    toast({
      title: "Notifications mises à jour",
      description: "Vos préférences de notification ont été mises à jour avec succès.",
    });
  };
  
  const handleSaveSecurity = () => {
    toast({
      title: "Sécurité mise à jour",
      description: "Vos paramètres de sécurité ont été mises à jour avec succès.",
    });
  };
  
  const handleDeleteAccount = () => {
    toast({
      title: "Attention",
      description: "Cette fonctionnalité n'est pas disponible dans la démo.",
      variant: "destructive",
    });
  };

  const handleFaceIDToggle = (checked: boolean) => {
    setUseFaceID(checked);
    
    if (currentUser) {
      if (checked) {
        localStorage.setItem(`faceID_${currentUser.username}`, 'true');
        toast({
          title: "Face ID activé",
          description: "L'authentification par Face ID a été activée.",
        });
      } else {
        localStorage.removeItem(`faceID_${currentUser.username}`);
        toast({
          title: "Face ID désactivé",
          description: "L'authentification par Face ID a été désactivée.",
        });
      }
    } else {
      toast({
        title: "Erreur",
        description: "Vous devez être connecté pour utiliser cette fonctionnalité.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Paramètres</h1>
      
      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid grid-cols-4 max-w-md mb-4">
          <TabsTrigger value="profile" className="flex items-center justify-center">
            <User className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Profil</span>
          </TabsTrigger>
          <TabsTrigger value="preferences" className="flex items-center justify-center">
            <SettingsIcon className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Préférences</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center justify-center">
            <Bell className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center justify-center">
            <Lock className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Sécurité</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Informations personnelles</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Prénom
                  </label>
                  <Input placeholder="Prénom" defaultValue="Jean" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nom
                  </label>
                  <Input placeholder="Nom" defaultValue="Dupont" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <Input placeholder="Email" defaultValue="jean.dupont@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Téléphone
                  </label>
                  <Input placeholder="Téléphone" defaultValue="+33 6 12 34 56 78" />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Adresse
                </label>
                <Textarea 
                  placeholder="Adresse" 
                  defaultValue="123 Rue des Exemples, 75000 Paris, France" 
                />
              </div>
              
              <div className="flex justify-end">
                <Button 
                  onClick={handleSaveProfile}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Enregistrer les modifications
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>
        
        <TabsContent value="preferences">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4 dark:text-gray-100">Préférences d'affichage</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-medium dark:text-gray-100">Mode sombre</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Basculer vers un thème sombre pour l'interface
                  </p>
                </div>
                <Switch 
                  checked={darkMode} 
                  onCheckedChange={setDarkMode} 
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Devise
                </label>
                <Select
                  value={currency}
                  onValueChange={setCurrency}
                >
                  <SelectTrigger className="w-full md:w-60">
                    <SelectValue placeholder="Sélectionner une devise" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EUR">Euro (€)</SelectItem>
                    <SelectItem value="USD">Dollar américain ($)</SelectItem>
                    <SelectItem value="GBP">Livre sterling (£)</SelectItem>
                    <SelectItem value="JPY">Yen japonais (¥)</SelectItem>
                    <SelectItem value="CHF">Franc suisse (CHF)</SelectItem>
                    <SelectItem value="MAD">Dirham marocain (DH)</SelectItem>
                    <SelectItem value="GNF">Franc guinéen (FG)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  onClick={handleSavePreferences}
                  className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800"
                >
                  Enregistrer les préférences
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Préférences de notifications</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-medium">Notifications par email</h3>
                  <p className="text-sm text-gray-500">
                    Recevoir des notifications par email
                  </p>
                </div>
                <Switch 
                  checked={emailNotifications} 
                  onCheckedChange={setEmailNotifications} 
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-medium">Notifications push</h3>
                  <p className="text-sm text-gray-500">
                    Recevoir des notifications dans le navigateur
                  </p>
                </div>
                <Switch 
                  checked={pushNotifications} 
                  onCheckedChange={setPushNotifications} 
                />
              </div>
              
              <div className="border-t pt-4">
                <h3 className="text-base font-medium mb-3">Types de notifications</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium">Alertes de budget</h4>
                      <p className="text-xs text-gray-500">
                        Notifications lorsque vous approchez ou dépassez vos limites de budget
                      </p>
                    </div>
                    <Switch 
                      checked={budgetAlerts} 
                      onCheckedChange={setBudgetAlerts} 
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium">Rappels d'objectifs</h4>
                      <p className="text-xs text-gray-500">
                        Rappels concernant vos objectifs d'épargne et échéances
                      </p>
                    </div>
                    <Switch 
                      checked={goalReminders} 
                      onCheckedChange={setGoalReminders} 
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  onClick={handleSaveNotifications}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Enregistrer les notifications
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4 dark:text-gray-100">Sécurité</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-medium dark:text-gray-100">Authentification Face ID</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Se connecter avec reconnaissance faciale
                  </p>
                </div>
                <Switch 
                  checked={useFaceID}
                  onCheckedChange={handleFaceIDToggle}
                  disabled={!currentUser}
                />
              </div>

              <div className="space-y-4">
                <h3 className="text-base font-medium dark:text-gray-100">Changer le mot de passe</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Mot de passe actuel
                  </label>
                  <Input type="password" placeholder="••••••••" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Nouveau mot de passe
                  </label>
                  <Input type="password" placeholder="••••••••" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Confirmer le nouveau mot de passe
                  </label>
                  <Input type="password" placeholder="••••••••" />
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    onClick={handleSaveSecurity}
                    className="bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800"
                  >
                    Mettre à jour le mot de passe
                  </Button>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h3 className="text-base font-medium text-red-600 mb-3">Zone dangereuse</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  Cette action est irréversible et supprimera définitivement toutes vos données.
                </p>
                <Button 
                  variant="destructive" 
                  onClick={handleDeleteAccount}
                >
                  Supprimer mon compte
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
