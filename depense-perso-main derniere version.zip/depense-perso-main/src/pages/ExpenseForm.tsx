
import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useExpenseStore } from '@/store/useExpenseStore';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { ExpenseCategory } from '@/types/expense';

const ExpenseForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const expenses = useExpenseStore((state) => state.expenses);
  const addExpense = useExpenseStore((state) => state.addExpense);
  const updateExpense = useExpenseStore((state) => state.updateExpense);
  const categorizeExpenseAutomatically = useExpenseStore(
    (state) => state.categorizeExpenseAutomatically
  );
  
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('autres');
  const [date, setDate] = useState(new Date().toISOString().substring(0, 10));
  
  const isEditing = !!id;
  
  useEffect(() => {
    if (isEditing) {
      const expense = expenses.find(e => e.id === id);
      if (expense) {
        setDescription(expense.description);
        setAmount(expense.amount.toString());
        setCategory(expense.category);
        setDate(expense.date.substring(0, 10));
      }
    }
  }, [id, expenses, isEditing]);
  
  const handleDescriptionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newDescription = e.target.value;
    setDescription(newDescription);
    
    // Catégorisation automatique seulement lors de la création
    if (!isEditing && newDescription.length > 3) {
      const suggestedCategory = categorizeExpenseAutomatically(newDescription);
      if (suggestedCategory !== category) {
        setCategory(suggestedCategory);
      }
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!description || !amount || !category || !date) {
      toast({
        title: "Formulaire incomplet",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive",
      });
      return;
    }
    
    const parsedAmount = parseFloat(amount);
    
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      toast({
        title: "Montant invalide",
        description: "Veuillez entrer un montant positif",
        variant: "destructive",
      });
      return;
    }
    
    if (isEditing) {
      updateExpense(id, {
        description,
        amount: parsedAmount,
        category,
        date,
      });
      
      toast({
        title: "Dépense mise à jour",
        description: "La dépense a été modifiée avec succès",
      });
    } else {
      addExpense({
        description,
        amount: parsedAmount,
        category,
        date,
      });
      
      toast({
        title: "Dépense ajoutée",
        description: "La dépense a été ajoutée avec succès",
      });
    }
    
    navigate('/expenses');
  };
  
  const categories: ExpenseCategory[] = [
    'nourriture', 'transport', 'loisirs', 'logement', 
    'santé', 'éducation', 'shopping', 'factures', 'autres'
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">
          {isEditing ? 'Modifier la dépense' : 'Ajouter une dépense'}
        </h1>
        <p className="text-gray-500 mt-1">
          {isEditing 
            ? 'Modifiez les détails de votre dépense ci-dessous.' 
            : 'Remplissez le formulaire pour ajouter une nouvelle dépense.'}
        </p>
      </div>
      
      <Card className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <Textarea
                placeholder="Décrivez votre dépense"
                value={description}
                onChange={handleDescriptionChange}
                className="min-h-[80px]"
              />
              {!isEditing && category !== 'autres' && (
                <p className="text-sm text-blue-600 mt-1">
                  Catégorie suggérée: {category}
                </p>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Montant (€)
                </label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Catégorie
                </label>
                <Select
                  value={category}
                  onValueChange={(value) => setCategory(value as ExpenseCategory)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner une catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat.charAt(0).toUpperCase() + cat.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <Input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/expenses')}
            >
              Annuler
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              {isEditing ? 'Mettre à jour' : 'Ajouter'}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default ExpenseForm;
