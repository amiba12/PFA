
import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useExpenseStore } from "@/store/useExpenseStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/components/ui/use-toast";
import { Camera, User, Fingerprint, LogIn } from "lucide-react";
import { motion } from "framer-motion";

const formSchema = z.object({
  username: z.string().min(2, {
    message: "Le nom d'utilisateur doit comporter au moins 2 caractères.",
  }),
  password: z.string().min(6, {
    message: "Le mot de passe doit comporter au moins 6 caractères.",
  }),
  rememberMe: z.boolean().default(false),
});

type FormValues = z.infer<typeof formSchema>;

export default function Login() {
  const [isFaceIDActive, setIsFaceIDActive] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { login, users } = useExpenseStore();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  const onSubmit = (data: FormValues) => {
    const success = login(data.username, data.password);
    if (success) {
      toast({
        title: "Connexion réussie",
        description: "Bienvenue sur TrackEase.",
      });
      navigate("/dashboard");
    } else {
      toast({
        title: "Connexion échouée",
        description: "Nom d'utilisateur ou mot de passe incorrect.",
        variant: "destructive",
      });
    }
  };

  const handleFaceIDLogin = () => {
    setShowCamera(true);
    setTimeout(() => {
      simulateFaceIDSuccess();
    }, 3000);
  };

  const simulateFaceIDSuccess = () => {
    setShowCamera(false);
    toast({
      title: "Authentification Face ID",
      description: "Face ID reconnu avec succès. Connexion en cours...",
    });
    
    // Find a user with Face ID enabled (in a real app, this would verify against stored face data)
    const faceIdUser = users.find(user => 
      localStorage.getItem(`faceID_${user.username}`) === 'true'
    );
    
    if (faceIdUser) {
      const success = login(faceIdUser.username, faceIdUser.password);
      if (success) {
        navigate("/dashboard");
      } else {
        toast({
          title: "Connexion échouée",
          description: "Erreur lors de l'authentification.",
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "Face ID non configuré",
        description: "Aucun utilisateur n'a configuré Face ID. Veuillez d'abord activer Face ID dans les paramètres ou lors de l'inscription.",
        variant: "destructive",
      });
    }
  };

  const checkFaceIDAvailability = () => {
    // Check if any user has Face ID enabled
    const hasUserWithFaceID = users.some(user => 
      localStorage.getItem(`faceID_${user.username}`) === 'true'
    );
    setIsFaceIDActive(hasUserWithFaceID);
  };

  useEffect(() => {
    checkFaceIDAvailability();
  }, [users]);

  const formVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.5,
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } }
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 sm:p-6 md:p-24">
      <motion.div 
        className="w-full max-w-md space-y-6"
        initial="hidden"
        animate="visible"
        variants={formVariants}
      >
        <motion.div className="space-y-2 text-center" variants={itemVariants}>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Connexion</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Connectez-vous à votre compte TrackEase
          </p>
        </motion.div>

        {showCamera ? (
          <motion.div 
            className="relative flex flex-col items-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="w-full h-64 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg flex items-center justify-center border border-blue-100 shadow-inner">
              <Camera className="w-12 h-12 text-blue-400 animate-pulse" />
            </div>
            <p className="mt-4 text-sm text-blue-500 animate-pulse">
              Analyse de votre visage en cours...
            </p>
            <Button 
              variant="outline" 
              className="mt-4 border-blue-300 text-blue-600 hover:bg-blue-50"
              onClick={() => setShowCamera(false)}
            >
              Annuler
            </Button>
          </motion.div>
        ) : (
          <>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <motion.div variants={itemVariants}>
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nom d'utilisateur</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="john.doe" 
                            {...field} 
                            className="border-blue-200 focus:border-blue-400 transition-colors duration-200"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </motion.div>
                
                <motion.div variants={itemVariants}>
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mot de passe</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="••••••••" 
                            {...field} 
                            className="border-blue-200 focus:border-blue-400 transition-colors duration-200"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </motion.div>
                
                <motion.div variants={itemVariants}>
                  <FormField
                    control={form.control}
                    name="rememberMe"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>Se souvenir de moi</FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </motion.div>
                
                <motion.div variants={itemVariants}>
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 transform hover:-translate-y-1"
                  >
                    <LogIn className="mr-2 h-4 w-4" />
                    Se connecter
                  </Button>
                </motion.div>
              </form>
            </Form>

            {isFaceIDActive && (
              <motion.div 
                className="flex flex-col items-center pt-2"
                variants={itemVariants}
              >
                <div className="relative w-full">
                  <Button 
                    variant="outline" 
                    className="w-full border-blue-300 text-blue-600 hover:bg-blue-50 transition-all duration-300 transform hover:-translate-y-1"
                    onClick={handleFaceIDLogin}
                  >
                    <Fingerprint className="mr-2 h-4 w-4" />
                    Se connecter avec Face ID
                  </Button>
                </div>
              </motion.div>
            )}

            <motion.div 
              className="mt-4 text-center text-sm"
              variants={itemVariants}
            >
              <p>
                Vous n'avez pas de compte ?{" "}
                <Link
                  to="/signup"
                  className="font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300 transition-colors"
                >
                  S'inscrire
                </Link>
              </p>
            </motion.div>
          </>
        )}
      </motion.div>
    </div>
  );
}
