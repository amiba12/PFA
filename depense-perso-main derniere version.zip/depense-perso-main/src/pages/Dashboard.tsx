
import { useExpenseStore } from '@/store/useExpenseStore';
import { Card } from '@/components/ui/card';
import { BarChart, Bar, PieChart, Pie, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Target, AlertCircle } from 'lucide-react';
import ExpenseSummaryCard from '@/components/expenses/ExpenseSummaryCard';
import RecentExpenses from '@/components/expenses/RecentExpenses';
import SpendingLimitsManager from '@/components/expenses/SpendingLimitsManager';

// Couleurs pour les graphiques
const COLORS = [
  '#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8',
  '#82CA9D', '#FF6B6B', '#6A7FDB', '#9CCC65'
];

const Dashboard = () => {
  const expenses = useExpenseStore((state) => state.expenses);
  const savingGoals = useExpenseStore((state) => state.savingGoals);
  const getExpensesByCategory = useExpenseStore((state) => state.getExpensesByCategory);
  const getMonthlyExpenses = useExpenseStore((state) => state.getMonthlyExpenses);
  const getTotalExpenses = useExpenseStore((state) => state.getTotalExpenses);
  
  // Données pour le graphique par catégorie
  const categoryData = Object.entries(getExpensesByCategory()).map(([category, amount], index) => ({
    name: category,
    value: amount,
    color: COLORS[index % COLORS.length]
  }));
  
  // Données pour le graphique mensuel
  const monthlyData = Object.entries(getMonthlyExpenses())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([month, amount]) => ({
      month: month.substring(5, 7) + '/' + month.substring(0, 4),
      amount
    }));
  
  // Calcul de la moyenne des dépenses quotidiennes ce mois-ci
  const currentMonth = new Date().toISOString().substring(0, 7);
  const currentMonthExpenses = expenses.filter(e => e.date.startsWith(currentMonth));
  const dailyAverage = currentMonthExpenses.length 
    ? currentMonthExpenses.reduce((sum, exp) => sum + exp.amount, 0) / 30 
    : 0;
    
  // Calcul objectif le plus proche
  const closestGoal = savingGoals.length 
    ? savingGoals.reduce((closest, goal) => {
        const percentComplete = (goal.currentAmount / goal.targetAmount) * 100;
        if (!closest || percentComplete > (closest.currentAmount / closest.targetAmount) * 100) {
          return goal;
        }
        return closest;
      }, null as null | typeof savingGoals[0])
    : null;
  
  // Total des dépenses
  const totalExpenses = getTotalExpenses();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Tableau de bord</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <ExpenseSummaryCard 
          title="Total dépensé"
          amount={totalExpenses}
          icon={<TrendingUp className="h-5 w-5 text-blue-500" />}
          trend={{ value: '12%', isPositive: false, label: 'vs. mois dernier' }}
          className="bg-white"
        />
        
        <ExpenseSummaryCard 
          title="Moyenne quotidienne"
          amount={dailyAverage}
          icon={<TrendingDown className="h-5 w-5 text-green-500" />}
          trend={{ value: '5%', isPositive: true, label: 'vs. mois dernier' }}
          className="bg-white"
        />
        
        <ExpenseSummaryCard 
          title="Objectifs"
          count={savingGoals.length}
          icon={<Target className="h-5 w-5 text-purple-500" />}
          secondaryLabel={closestGoal ? `${(closestGoal.currentAmount / closestGoal.targetAmount * 100).toFixed(0)}% - ${closestGoal.name}` : "Aucun objectif"}
          className="bg-white"
        />
        
        <ExpenseSummaryCard 
          title="Dépenses du mois"
          amount={monthlyData.length > 0 ? monthlyData[monthlyData.length - 1].amount : 0}
          icon={<AlertCircle className="h-5 w-5 text-orange-500" />}
          trend={{ value: '8%', isPositive: false, label: 'vs. mois dernier' }}
          className="bg-white"
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-4">
          <h2 className="text-lg font-medium mb-4">Répartition par catégorie</h2>
          <div className="aspect-square h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value} €`, 'Montant']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
        
        <Card className="p-4">
          <h2 className="text-lg font-medium mb-4">Évolution mensuelle</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={monthlyData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value} €`, 'Montant']} />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="amount" 
                  name="Dépenses"
                  stroke="#8884d8" 
                  activeDot={{ r: 8 }} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
      
      <Card className="p-6">
        <SpendingLimitsManager />
      </Card>
      
      <RecentExpenses limit={5} />
    </div>
  );
};

export default Dashboard;
