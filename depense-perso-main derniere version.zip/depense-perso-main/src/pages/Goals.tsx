
import { useState } from 'react';
import { useExpenseStore } from '@/store/useExpenseStore';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/components/ui/use-toast';
import { Plus, Edit2, Trash2 } from 'lucide-react';

const Goals = () => {
  const savingGoals = useExpenseStore((state) => state.savingGoals);
  const addSavingGoal = useExpenseStore((state) => state.addSavingGoal);
  const updateSavingGoal = useExpenseStore((state) => state.updateSavingGoal);
  const deleteSavingGoal = useExpenseStore((state) => state.deleteSavingGoal);
  const updateSavingGoalAmount = useExpenseStore((state) => state.updateSavingGoalAmount);
  const calculateSavingsNeeded = useExpenseStore((state) => state.calculateSavingsNeeded);
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [deadline, setDeadline] = useState('');
  
  const [showDeposit, setShowDeposit] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState('');
  
  const openAddDialog = () => {
    setIsEditMode(false);
    setEditingId(null);
    setName('');
    setTargetAmount('');
    setDeadline('');
    setIsDialogOpen(true);
  };
  
  const openEditDialog = (id: string) => {
    const goal = savingGoals.find(g => g.id === id);
    if (goal) {
      setIsEditMode(true);
      setEditingId(id);
      setName(goal.name);
      setTargetAmount(goal.targetAmount.toString());
      setDeadline(goal.deadline.substring(0, 10));
      setIsDialogOpen(true);
    }
  };
  
  const handleSubmit = () => {
    if (!name || !targetAmount || !deadline) {
      toast({
        title: "Formulaire incomplet",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive",
      });
      return;
    }
    
    const parsedAmount = parseFloat(targetAmount);
    
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      toast({
        title: "Montant invalide",
        description: "Veuillez entrer un montant positif",
        variant: "destructive",
      });
      return;
    }
    
    if (isEditMode && editingId) {
      updateSavingGoal(editingId, {
        name,
        targetAmount: parsedAmount,
        deadline,
      });
      
      toast({
        title: "Objectif mis à jour",
        description: "L'objectif d'épargne a été modifié avec succès",
      });
    } else {
      addSavingGoal({
        name,
        targetAmount: parsedAmount,
        deadline,
      });
      
      toast({
        title: "Objectif ajouté",
        description: "L'objectif d'épargne a été ajouté avec succès",
      });
    }
    
    setIsDialogOpen(false);
  };
  
  const handleDelete = (id: string) => {
    deleteSavingGoal(id);
    toast({
      title: "Objectif supprimé",
      description: "L'objectif d'épargne a été supprimé avec succès",
    });
  };
  
  const handleDeposit = (id: string) => {
    const parsedAmount = parseFloat(depositAmount);
    
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      toast({
        title: "Montant invalide",
        description: "Veuillez entrer un montant positif",
        variant: "destructive",
      });
      return;
    }
    
    const goal = savingGoals.find(g => g.id === id);
    if (goal) {
      const newAmount = goal.currentAmount + parsedAmount;
      updateSavingGoalAmount(id, newAmount);
      
      toast({
        title: "Dépôt effectué",
        description: `${parsedAmount.toFixed(2)} € ont été ajoutés à votre objectif "${goal.name}"`,
      });
      
      setShowDeposit(null);
      setDepositAmount('');
      
      if (newAmount >= goal.targetAmount) {
        toast({
          title: "Félicitations! 🎉",
          description: `Vous avez atteint votre objectif "${goal.name}"!`,
          variant: "default",
          duration: 5000,
        });
      }
    }
  };
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
    }).format(amount);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('fr-FR').format(date);
  };
  
  const calculateDaysLeft = (deadlineString: string) => {
    const deadline = new Date(deadlineString);
    const today = new Date();
    const diffTime = deadline.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Objectifs d'épargne</h1>
          <p className="text-gray-500 mt-1">
            Définissez et suivez vos objectifs d'épargne pour atteindre vos rêves.
          </p>
        </div>
        <Button onClick={openAddDialog} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="mr-2" />
          Créer un objectif
        </Button>
      </div>
      
      {savingGoals.length === 0 ? (
        <Card className="p-8 text-center">
          <div className="text-4xl mb-4">🎯</div>
          <h2 className="text-xl font-medium mb-2">Aucun objectif d'épargne</h2>
          <p className="text-gray-500 mb-4">
            Créez votre premier objectif pour commencer à épargner intelligemment.
          </p>
          <Button onClick={openAddDialog} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="mr-2" />
            Créer un objectif
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {savingGoals.map((goal) => {
            const progress = (goal.currentAmount / goal.targetAmount) * 100;
            const daysLeft = calculateDaysLeft(goal.deadline);
            const { weekly, monthly } = calculateSavingsNeeded(goal.id);
            
            return (
              <Card key={goal.id} className="p-5">
                <div className="flex justify-between mb-3">
                  <h3 className="text-lg font-medium">{goal.name}</h3>
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEditDialog(goal.id)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(goal.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Progression</span>
                      <span className="font-medium">{progress.toFixed(0)}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <div className="text-gray-500">Économisé</div>
                      <div className="font-medium">{formatCurrency(goal.currentAmount)}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Objectif</div>
                      <div className="font-medium">{formatCurrency(goal.targetAmount)}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Reste à économiser</div>
                      <div className="font-medium">{formatCurrency(goal.targetAmount - goal.currentAmount)}</div>
                    </div>
                    <div>
                      <div className="text-gray-500">Échéance</div>
                      <div className="font-medium">
                        {formatDate(goal.deadline)}
                        {daysLeft > 0 ? ` (${daysLeft} jours)` : ' (Expiré)'}
                      </div>
                    </div>
                  </div>
                  
                  {/* Nouvelle section pour afficher l'épargne hebdomadaire et mensuelle nécessaire */}
                  {daysLeft > 0 && (
                    <div className="mt-2 p-3 bg-blue-50 rounded-md">
                      <h4 className="font-medium text-blue-800 mb-2">Plan d'épargne suggéré</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <div className="text-blue-600">Par semaine</div>
                          <div className="font-medium">{formatCurrency(weekly)}</div>
                        </div>
                        <div>
                          <div className="text-blue-600">Par mois</div>
                          <div className="font-medium">{formatCurrency(monthly)}</div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {showDeposit === goal.id ? (
                    <div className="flex items-center space-x-2 mt-4">
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Montant"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        className="max-w-[150px]"
                      />
                      <Button 
                        size="sm" 
                        onClick={() => handleDeposit(goal.id)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Confirmer
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => setShowDeposit(null)}
                      >
                        Annuler
                      </Button>
                    </div>
                  ) : (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-4"
                      onClick={() => {
                        setShowDeposit(goal.id);
                        setDepositAmount('');
                      }}
                    >
                      Ajouter un dépôt
                    </Button>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {isEditMode ? 'Modifier l\'objectif' : 'Créer un objectif d\'épargne'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nom de l'objectif
              </label>
              <Input
                placeholder="Ex: Voyage à Rome"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Montant cible (€)
              </label>
              <Input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={targetAmount}
                onChange={(e) => setTargetAmount(e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date d'échéance
              </label>
              <Input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDialogOpen(false)}
            >
              Annuler
            </Button>
            <Button onClick={handleSubmit} className="bg-blue-600 hover:bg-blue-700">
              {isEditMode ? 'Mettre à jour' : 'Créer l\'objectif'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Goals;
