
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useExpenseStore } from "@/store/useExpenseStore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/components/ui/use-toast";
import { Camera, CheckCircle, Fingerprint } from "lucide-react";

const formSchema = z.object({
  username: z.string().min(2, {
    message: "Le nom d'utilisateur doit comporter au moins 2 caractères.",
  }),
  email: z.string().email({
    message: "Veuillez saisir une adresse email valide.",
  }),
  password: z.string().min(6, {
    message: "Le mot de passe doit comporter au moins 6 caractères.",
  }),
  confirmPassword: z.string(),
  terms: z.boolean().refine((value) => value === true, {
    message: "Vous devez accepter les conditions d'utilisation.",
  }),
  useFaceID: z.boolean().default(false),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas.",
  path: ["confirmPassword"],
});

type FormValues = z.infer<typeof formSchema>;

export default function Signup() {
  const [showCamera, setShowCamera] = useState(false);
  const [faceIDRegistered, setFaceIDRegistered] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { addUser } = useExpenseStore();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      terms: false,
      useFaceID: false,
    },
  });

  const onSubmit = (data: FormValues) => {
    // If user opted for Face ID but didn't complete registration
    if (data.useFaceID && !faceIDRegistered) {
      toast({
        title: "Face ID requis",
        description: "Veuillez compléter l'enregistrement Face ID avant de continuer.",
        variant: "destructive",
      });
      return;
    }

    addUser({
      username: data.username,
      email: data.email,
      password: data.password,
    });

    if (data.useFaceID) {
      // Store Face ID association per user
      localStorage.setItem(`faceID_${data.username}`, 'true');
    }

    toast({
      title: "Inscription réussie",
      description: "Votre compte a été créé avec succès.",
    });

    navigate("/login");
  };

  const handleStartFaceIDRegistration = () => {
    setShowCamera(true);
    setTimeout(() => {
      simulateFaceIDRegistration();
    }, 3000);
  };

  const simulateFaceIDRegistration = () => {
    setShowCamera(false);
    setFaceIDRegistered(true);
    toast({
      title: "Face ID enregistré",
      description: "Votre visage a été enregistré avec succès.",
    });
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 sm:p-6 md:p-24">
      <div className="w-full max-w-md space-y-6">
        <div className="space-y-2 text-center">
          <h1 className="text-3xl font-bold">Créer un compte</h1>
          <p className="text-gray-500 dark:text-gray-400">
            Inscrivez-vous pour commencer à utiliser TrackEase
          </p>
        </div>

        {showCamera ? (
          <div className="relative flex flex-col items-center">
            <div className="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
              <Camera className="w-12 h-12 text-gray-400 animate-pulse" />
            </div>
            <p className="mt-4 text-sm text-gray-500 animate-pulse">
              Analyse de votre visage en cours...
            </p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => setShowCamera(false)}
            >
              Annuler
            </Button>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nom d'utilisateur</FormLabel>
                    <FormControl>
                      <Input placeholder="john.doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="john.doe@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mot de passe</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirmer le mot de passe</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="useFaceID"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Activer Face ID pour me connecter</FormLabel>
                    </div>
                  </FormItem>
                )}
              />

              {form.watch("useFaceID") && (
                <div className="border p-4 rounded-md">
                  {faceIDRegistered ? (
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Face ID enregistré</span>
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    </div>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full"
                      onClick={handleStartFaceIDRegistration}
                    >
                      <Fingerprint className="mr-2 h-4 w-4" />
                      Configurer Face ID
                    </Button>
                  )}
                </div>
              )}

              <FormField
                control={form.control}
                name="terms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>
                        J'accepte les{" "}
                        <Link
                          to="#"
                          className="text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
                        >
                          conditions d'utilisation
                        </Link>
                      </FormLabel>
                    </div>
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full">
                S'inscrire
              </Button>
            </form>
          </Form>
        )}

        <div className="mt-4 text-center text-sm">
          <p>
            Vous avez déjà un compte ?{" "}
            <Link
              to="/login"
              className="font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
            >
              Se connecter
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
