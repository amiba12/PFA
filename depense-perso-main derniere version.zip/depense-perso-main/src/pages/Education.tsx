import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ExternalLink, Video, FileText } from 'lucide-react';
import { BookOpen } from 'lucide-react';

const articles = [
  {
    title: "Comment établir un budget efficace",
    summary: "Apprenez à créer et maintenir un budget qui fonctionne avec votre style de vie.",
    category: "budget",
    readTime: "5 min",
    imageUrl: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
  {
    title: "Comprendre les différents types d'épargne",
    summary: "Découvrez les options d'épargne disponibles et comment les utiliser à votre avantage.",
    category: "epargne",
    readTime: "7 min",
    imageUrl: "https://images.unsplash.com/photo-1579621970588-a35d0e7ab9b6?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
  {
    title: "Réduire vos dépenses quotidiennes",
    summary: "Des conseils pratiques pour économiser de l'argent au jour le jour sans sacrifier votre qualité de vie.",
    category: "economie",
    readTime: "4 min",
    imageUrl: "https://images.unsplash.com/photo-1607863680198-23d4b2565df0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
  {
    title: "Investir pour débutants",
    summary: "Un guide simple pour comprendre les bases de l'investissement et commencer avec un petit capital.",
    category: "investissement",
    readTime: "10 min",
    imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
  {
    title: "Planifier sa retraite dès maintenant",
    summary: "Pourquoi et comment commencer à préparer votre retraite, peu importe votre âge actuel.",
    category: "retraite",
    readTime: "8 min",
    imageUrl: "https://images.unsplash.com/photo-1556742031-c6961e8560b0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
];

const videos = [
  {
    title: "Masterclass: Gestion financière en 30 minutes",
    summary: "Une introduction complète aux principes fondamentaux de la gestion financière personnelle.",
    duration: "32:14",
    thumbnailUrl: "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
  {
    title: "5 habitudes des personnes financièrement indépendantes",
    summary: "Découvrez les comportements quotidiens qui mènent à la liberté financière.",
    duration: "15:47",
    thumbnailUrl: "https://images.unsplash.com/photo-1664575599618-8f6bd76fc670?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
  {
    title: "Comment sortir des dettes rapidement",
    summary: "Une stratégie étape par étape pour éliminer vos dettes et retrouver votre liberté financière.",
    duration: "22:09",
    thumbnailUrl: "https://images.unsplash.com/photo-1579621970795-87facc2f976d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
  },
];

const tools = [
  {
    title: "Calculateur d'amortissement de prêt",
    description: "Planifiez vos remboursements de prêt et voyez comment les paiements supplémentaires peuvent réduire votre durée de remboursement.",
    icon: "🧮",
  },
  {
    title: "Simulateur d'épargne",
    description: "Visualisez la croissance de votre épargne au fil du temps avec différents taux d'intérêt et contributions.",
    icon: "📊",
  },
  {
    title: "Comparateur de budgets",
    description: "Comparez vos habitudes de dépenses avec les moyennes nationales par catégorie.",
    icon: "📋",
  },
  {
    title: "Calculateur d'objectifs financiers",
    description: "Déterminez combien vous devez épargner chaque mois pour atteindre vos objectifs dans un délai spécifique.",
    icon: "🎯",
  },
];

const Education = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Éducation financière</h1>
        <p className="text-gray-500 mt-1">
          Développez vos connaissances financières avec nos ressources et outils.
        </p>
      </div>
      
      <Tabs defaultValue="articles">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="articles" className="flex items-center">
            <FileText className="mr-2 h-4 w-4" />
            Articles
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex items-center">
            <Video className="mr-2 h-4 w-4" />
            Vidéos
          </TabsTrigger>
          <TabsTrigger value="tools" className="flex items-center">
            <BookOpen className="mr-2 h-4 w-4" />
            Outils
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="articles" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article, index) => (
              <Card key={index} className="overflow-hidden">
                <div 
                  className="h-40 bg-cover bg-center" 
                  style={{ backgroundImage: `url(${article.imageUrl})` }}
                />
                <div className="p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-medium px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                      {article.category}
                    </span>
                    <span className="text-xs text-gray-500">
                      {article.readTime} de lecture
                    </span>
                  </div>
                  <h3 className="text-lg font-medium mb-2">{article.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{article.summary}</p>
                  <Button variant="ghost" size="sm" className="flex items-center text-blue-600">
                    Lire l'article
                    <ExternalLink className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="text-center">
            <Button variant="outline">Voir plus d'articles</Button>
          </div>
        </TabsContent>
        
        <TabsContent value="videos" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="relative">
                  <div 
                    className="h-48 bg-cover bg-center" 
                    style={{ backgroundImage: `url(${video.thumbnailUrl})` }}
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-white/80 flex items-center justify-center">
                      <div className="w-0 h-0 border-t-8 border-t-transparent border-l-[16px] border-l-blue-600 border-b-8 border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    {video.duration}
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-medium mb-2">{video.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{video.summary}</p>
                  <Button variant="ghost" size="sm" className="flex items-center text-blue-600">
                    Regarder la vidéo
                    <ExternalLink className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="text-center">
            <Button variant="outline">Voir plus de vidéos</Button>
          </div>
        </TabsContent>
        
        <TabsContent value="tools" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {tools.map((tool, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-start">
                  <div className="text-3xl mr-4">{tool.icon}</div>
                  <div>
                    <h3 className="text-lg font-medium mb-2">{tool.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{tool.description}</p>
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Accéder à l'outil
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      
      <Card className="p-6 bg-blue-50 border-blue-200">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-2/3 mb-4 md:mb-0">
            <h2 className="text-xl font-semibold text-blue-900 mb-2">Rejoignez notre newsletter financière</h2>
            <p className="text-blue-700">
              Recevez chaque semaine des conseils financiers, des actualités et des astuces pour gérer votre argent intelligemment.
            </p>
          </div>
          <div className="md:w-1/3 flex justify-center md:justify-end">
            <Button className="bg-blue-700 hover:bg-blue-800">
              S'inscrire gratuitement
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Education;
