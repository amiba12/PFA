import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useExpenseStore } from '@/store/useExpenseStore';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Plus, Filter, Search } from 'lucide-react';
import { ExpenseCategory } from '@/types/expense';
import RecentExpenses from '@/components/expenses/RecentExpenses';

const Expenses = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<ExpenseCategory | 'all'>('all');
  
  const categories: ExpenseCategory[] = [
    'nourriture', 'transport', 'loisirs', 'logement', 
    'santé', 'éducation', 'shopping', 'factures', 'autres'
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Gestion des dépenses</h1>
        <Button 
          onClick={() => navigate('/expenses/add')}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="mr-2" />
          Ajouter une dépense
        </Button>
      </div>
      
      <Card className="p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input 
              placeholder="Rechercher des dépenses..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="w-full md:w-64 flex items-center gap-2">
            <Filter className="text-gray-400" />
            <Select
              value={categoryFilter}
              onValueChange={(value) => setCategoryFilter(value as ExpenseCategory | 'all')}
            >
              <SelectTrigger>
                <SelectValue placeholder="Filtrer par catégorie" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les catégories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>
      
      <RecentExpenses />
    </div>
  );
};

export default Expenses;
