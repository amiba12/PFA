
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { v4 as uuidv4 } from 'uuid';
import { Expense, ExpenseCategory, SavingGoal } from '@/types/expense';

type User = {
  id?: string;
  username: string;
  email: string;
  password: string;
  spendingLimits?: Partial<Record<ExpenseCategory, number>>;
};

interface ExpenseStore {
  expenses: Expense[];
  savingGoals: SavingGoal[];
  isAuthenticated: boolean;
  users: User[];
  currentUser: User | null;
  
  addUser: (user: Omit<User, 'id'>) => void;
  login: (username: string, password: string) => boolean;
  logout: () => void;

  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => void;
  updateExpense: (id: string, expense: Partial<Omit<Expense, 'id' | 'createdAt'>>) => void;
  deleteExpense: (id: string) => void;
  addSavingGoal: (goal: Omit<SavingGoal, 'id' | 'createdAt' | 'currentAmount'>) => void;
  updateSavingGoal: (id: string, goal: Partial<Omit<SavingGoal, 'id' | 'createdAt'>>) => void;
  deleteSavingGoal: (id: string) => void;
  updateSavingGoalAmount: (id: string, amount: number) => void;
  
  getExpensesByCategory: () => Record<ExpenseCategory, number>;
  getMonthlyExpenses: () => Record<string, number>; // format "YYYY-MM": amount
  getTotalExpenses: () => number;
  categorizeExpenseAutomatically: (description: string) => ExpenseCategory;
  
  setSpendingLimit: (category: ExpenseCategory, amount: number) => void;
  getSpendingLimit: (category: ExpenseCategory) => number;
  getCurrentMonthExpensesByCategory: () => Record<ExpenseCategory, number>;
  getSpendingStatus: (category: ExpenseCategory) => { status: 'normal' | 'warning' | 'danger', percentage: number };
  calculateSavingsNeeded: (goalId: string) => { weekly: number, monthly: number };
}

const categorizationRules: Record<ExpenseCategory, string[]> = {
  nourriture: ['restaurant', 'supermarché', 'épicerie', 'café', 'pizza', 'boulangerie', 'marché'],
  transport: ['essence', 'carburant', 'train', 'métro', 'bus', 'taxi', 'uber', 'vélo', 'transport'],
  loisirs: ['cinéma', 'concert', 'théâtre', 'livre', 'jeu', 'sport', 'sortie', 'vacances', 'voyage'],
  logement: ['loyer', 'électricité', 'eau', 'gaz', 'internet', 'assurance', 'meuble', 'réparation'],
  santé: ['médecin', 'pharmacie', 'dentiste', 'optique', 'hôpital', 'mutuelle', 'santé'],
  éducation: ['cours', 'école', 'université', 'formation', 'livre', 'bibliothèque', 'éducation'],
  shopping: ['vêtement', 'chaussure', 'boutique', 'magasin', 'cadeau', 'shopping', 'achat'],
  factures: ['abonnement', 'facture', 'mensualité', 'paiement', 'compte', 'service'],
  autres: []
};

export const useExpenseStore = create<ExpenseStore>()(
  persist(
    (set, get) => ({
      expenses: [],
      savingGoals: [],
      isAuthenticated: false,
      users: [],
      currentUser: null,
      
      addUser: (user) => set((state) => ({
        users: [
          ...state.users,
          {
            ...user,
            id: uuidv4(),
            spendingLimits: {},
          }
        ]
      })),
      
      login: (username, password) => {
        const user = get().users.find(
          u => u.username === username && u.password === password
        );
        
        if (user) {
          set({ 
            isAuthenticated: true, 
            currentUser: user 
          });
          return true;
        }
        return false;
      },
      
      logout: () => set({ 
        isAuthenticated: false, 
        currentUser: null 
      }),
      
      addExpense: (expense) => set((state) => ({
        expenses: [
          ...state.expenses,
          {
            ...expense,
            id: uuidv4(),
            createdAt: new Date().toISOString()
          }
        ]
      })),
      
      updateExpense: (id, updatedExpense) => set((state) => ({
        expenses: state.expenses.map((expense) => 
          expense.id === id ? { ...expense, ...updatedExpense } : expense
        )
      })),
      
      deleteExpense: (id) => set((state) => ({
        expenses: state.expenses.filter((expense) => expense.id !== id)
      })),
      
      addSavingGoal: (goal) => set((state) => ({
        savingGoals: [
          ...state.savingGoals,
          {
            ...goal,
            id: uuidv4(),
            currentAmount: 0,
            createdAt: new Date().toISOString()
          }
        ]
      })),
      
      updateSavingGoal: (id, updatedGoal) => set((state) => ({
        savingGoals: state.savingGoals.map((goal) => 
          goal.id === id ? { ...goal, ...updatedGoal } : goal
        )
      })),
      
      deleteSavingGoal: (id) => set((state) => ({
        savingGoals: state.savingGoals.filter((goal) => goal.id !== id)
      })),
      
      updateSavingGoalAmount: (id, amount) => set((state) => ({
        savingGoals: state.savingGoals.map((goal) => 
          goal.id === id ? { ...goal, currentAmount: amount } : goal
        )
      })),
      
      setSpendingLimit: (category, amount) => set((state) => {
        if (!state.currentUser) return state;
        
        const updatedUsers = state.users.map(user => {
          if (user.id === state.currentUser?.id) {
            return {
              ...user,
              spendingLimits: {
                ...(user.spendingLimits || {}),
                [category]: amount
              }
            };
          }
          return user;
        });
        
        const updatedCurrentUser = {
          ...state.currentUser,
          spendingLimits: {
            ...(state.currentUser.spendingLimits || {}),
            [category]: amount
          }
        };
        
        return {
          ...state,
          users: updatedUsers,
          currentUser: updatedCurrentUser
        };
      }),
      
      getSpendingLimit: (category) => {
        const { currentUser } = get();
        if (!currentUser || !currentUser.spendingLimits) return 0;
        return currentUser.spendingLimits[category] || 0;
      },
      
      getCurrentMonthExpensesByCategory: () => {
        const { expenses } = get();
        const currentDate = new Date();
        const currentMonth = currentDate.toISOString().substring(0, 7); // format "YYYY-MM"
        
        return expenses
          .filter(expense => expense.date.startsWith(currentMonth))
          .reduce((acc, expense) => {
            acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
            return acc;
          }, {} as Record<ExpenseCategory, number>);
      },
      
      getSpendingStatus: (category) => {
        const currentMonthExpenses = get().getCurrentMonthExpensesByCategory();
        const limit = get().getSpendingLimit(category);
        
        if (limit <= 0) return { status: 'normal', percentage: 0 };
        
        const spent = currentMonthExpenses[category] || 0;
        const percentage = (spent / limit) * 100;
        
        if (percentage >= 100) {
          return { status: 'danger', percentage };
        } else if (percentage >= 80) {
          return { status: 'warning', percentage };
        } else {
          return { status: 'normal', percentage };
        }
      },
      
      calculateSavingsNeeded: (goalId) => {
        const { savingGoals } = get();
        const goal = savingGoals.find(g => g.id === goalId);
        
        if (!goal) return { weekly: 0, monthly: 0 };
        
        const today = new Date();
        const deadline = new Date(goal.deadline);
        const remainingAmount = goal.targetAmount - goal.currentAmount;
        
        if (remainingAmount <= 0 || deadline < today) {
          return { weekly: 0, monthly: 0 };
        }
        
        const totalDays = Math.max(1, Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
        const totalWeeks = Math.max(1, totalDays / 7);
        const totalMonths = Math.max(1, totalDays / 30);
        
        return {
          weekly: remainingAmount / totalWeeks,
          monthly: remainingAmount / totalMonths
        };
      },
      
      getExpensesByCategory: () => {
        const { expenses } = get();
        return expenses.reduce((acc, expense) => {
          acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
          return acc;
        }, {} as Record<ExpenseCategory, number>);
      },
      
      getMonthlyExpenses: () => {
        const { expenses } = get();
        return expenses.reduce((acc, expense) => {
          const month = expense.date.substring(0, 7); // format "YYYY-MM"
          acc[month] = (acc[month] || 0) + expense.amount;
          return acc;
        }, {} as Record<string, number>);
      },
      
      getTotalExpenses: () => {
        const { expenses } = get();
        return expenses.reduce((total, expense) => total + expense.amount, 0);
      },
      
      categorizeExpenseAutomatically: (description) => {
        const lowerDescription = description.toLowerCase();
        
        for (const [category, keywords] of Object.entries(categorizationRules)) {
          for (const keyword of keywords) {
            if (lowerDescription.includes(keyword.toLowerCase())) {
              return category as ExpenseCategory;
            }
          }
        }
        
        return "autres";
      }
    }),
    {
      name: 'trackease-storage',
      skipHydration: true,
    }
  )
);
