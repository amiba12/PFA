
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Welcome from "./pages/Welcome";
import Dashboard from "./pages/Dashboard";
import Expenses from "./pages/Expenses";
import ExpenseForm from "./pages/ExpenseForm";
import Goals from "./pages/Goals";
import Education from "./pages/Education";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
import AppLayout from "./components/layout/AppLayout";
import { useEffect } from "react";
import { useExpenseStore } from "./store/useExpenseStore";

const queryClient = new QueryClient();

const App = () => {
  // Rehydrate the store when the app loads
  useEffect(() => {
    useExpenseStore.persist.rehydrate();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Welcome />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            
            <Route path="/dashboard" element={<AppLayout><Dashboard /></AppLayout>} />
            
            <Route path="/expenses" element={<AppLayout><Expenses /></AppLayout>} />
            <Route path="/expenses/add" element={<AppLayout><ExpenseForm /></AppLayout>} />
            <Route path="/expenses/edit/:id" element={<AppLayout><ExpenseForm /></AppLayout>} />
            
            <Route path="/goals" element={<AppLayout><Goals /></AppLayout>} />
            <Route path="/education" element={<AppLayout><Education /></AppLayout>} />
            <Route path="/settings" element={<AppLayout><Settings /></AppLayout>} />
            
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
