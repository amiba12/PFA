
import React from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface ProjectImportTipProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

const ProjectImportTip = ({ title, description, icon }: ProjectImportTipProps) => {
  return (
    <Card className="p-4 border-l-4 border-l-blue-500">
      <div className="flex items-start">
        <div className="mr-4 text-blue-500">{icon}</div>
        <div>
          <h3 className="font-medium text-gray-900">{title}</h3>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
      </div>
    </Card>
  );
};

export default ProjectImportTip;
