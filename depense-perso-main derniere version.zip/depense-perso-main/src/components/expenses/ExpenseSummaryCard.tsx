
import React from 'react';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface Trend {
  value: string;
  isPositive: boolean;
  label: string;
}

interface ExpenseSummaryCardProps {
  title: string;
  amount?: number;
  count?: number;
  icon: React.ReactNode;
  trend?: Trend;
  secondaryLabel?: string;
  className?: string;
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
  }).format(amount);
};

const ExpenseSummaryCard = ({
  title,
  amount,
  count,
  icon,
  trend,
  secondaryLabel,
  className,
}: ExpenseSummaryCardProps) => {
  return (
    <Card className={cn("p-4", className)}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-gray-600">{title}</h3>
        <div className="h-8 w-8 rounded-full bg-blue-50 flex items-center justify-center">
          {icon}
        </div>
      </div>
      
      <div className="space-y-1">
        {amount !== undefined && (
          <div className="text-2xl font-bold">{formatCurrency(amount)}</div>
        )}
        
        {count !== undefined && (
          <div className="text-2xl font-bold">{count}</div>
        )}
        
        {trend && (
          <div className="flex items-center text-sm">
            <span
              className={
                trend.isPositive ? "text-green-600" : "text-red-600"
              }
            >
              {trend.isPositive ? "↓" : "↑"} {trend.value}
            </span>
            <span className="text-gray-500 ml-1">{trend.label}</span>
          </div>
        )}
        
        {secondaryLabel && (
          <div className="text-sm text-gray-600">{secondaryLabel}</div>
        )}
      </div>
    </Card>
  );
};

export default ExpenseSummaryCard;
