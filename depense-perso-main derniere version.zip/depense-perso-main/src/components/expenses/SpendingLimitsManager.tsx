
import { useState, useEffect } from 'react';
import { useExpenseStore } from '@/store/useExpenseStore';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { ExpenseCategory } from '@/types/expense';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/components/ui/use-toast';
import { AlertCircle, CheckCircle, AlertTriangle } from 'lucide-react';

const categories: ExpenseCategory[] = [
  'nourriture', 'transport', 'loisirs', 'logement', 
  'santé', 'éducation', 'shopping', 'factures', 'autres'
];

export const SpendingLimitsManager = () => {
  const setSpendingLimit = useExpenseStore((state) => state.setSpendingLimit);
  const getSpendingLimit = useExpenseStore((state) => state.getSpendingLimit);
  const getSpendingStatus = useExpenseStore((state) => state.getSpendingStatus);
  const getCurrentMonthExpensesByCategory = useExpenseStore((state) => state.getCurrentMonthExpensesByCategory);
  
  const [limits, setLimits] = useState<Record<ExpenseCategory, string>>({} as Record<ExpenseCategory, string>);
  const [currentExpenses, setCurrentExpenses] = useState<Record<ExpenseCategory, number>>({} as Record<ExpenseCategory, number>);
  const [statuses, setStatuses] = useState<Record<ExpenseCategory, { status: 'normal' | 'warning' | 'danger', percentage: number }>>({} as any);
  
  // Initial load of existing limits
  useEffect(() => {
    const initialLimits: Record<ExpenseCategory, string> = {} as Record<ExpenseCategory, string>;
    
    categories.forEach(category => {
      const limitValue = getSpendingLimit(category);
      initialLimits[category] = limitValue > 0 ? limitValue.toString() : '';
    });
    
    setLimits(initialLimits);
    updateExpensesAndStatuses();
  }, []);
  
  // Update expenses and statuses for all categories
  const updateExpensesAndStatuses = () => {
    const expenses = getCurrentMonthExpensesByCategory();
    setCurrentExpenses(expenses);
    
    const newStatuses: Record<ExpenseCategory, { status: 'normal' | 'warning' | 'danger', percentage: number }> = {} as any;
    categories.forEach(category => {
      newStatuses[category] = getSpendingStatus(category);
    });
    
    setStatuses(newStatuses);
  };
  
  const handleLimitChange = (category: ExpenseCategory, value: string) => {
    setLimits(prev => ({ ...prev, [category]: value }));
  };
  
  const handleSave = (category: ExpenseCategory) => {
    const limit = parseFloat(limits[category]);
    
    if (isNaN(limit) || limit <= 0) {
      toast({
        title: "Limite invalide",
        description: "Veuillez entrer un montant positif",
        variant: "destructive",
      });
      return;
    }
    
    setSpendingLimit(category, limit);
    updateExpensesAndStatuses();
    
    toast({
      title: "Limite enregistrée",
      description: `La limite pour ${category} a été mise à jour`,
    });
  };
  
  const getStatusColor = (status: 'normal' | 'warning' | 'danger') => {
    switch (status) {
      case 'danger': return 'bg-red-500';
      case 'warning': return 'bg-orange-500';
      case 'normal': return 'bg-green-500';
    }
  };
  
  const getAdviceCard = (category: ExpenseCategory) => {
    const status = statuses[category];
    const limit = parseFloat(limits[category]);
    
    if (isNaN(limit) || limit <= 0 || !status) return null;
    
    let icon;
    let title;
    let message;
    let variant: "default" | "destructive" = "default";
    
    if (status.status === 'danger') {
      icon = <AlertCircle className="h-5 w-5 text-red-500" />;
      title = "Attention, dépassement de budget!";
      message = `Vous avez dépassé votre budget pour la catégorie ${category}. Essayez de réduire vos dépenses dans cette catégorie pour le reste du mois.`;
      variant = "destructive";
    } else if (status.status === 'warning') {
      icon = <AlertTriangle className="h-5 w-5 text-orange-500" />;
      title = "Attention, budget presque atteint";
      message = `Vous avez utilisé ${status.percentage.toFixed(0)}% de votre budget pour ${category}. Soyez vigilant pour le reste du mois.`;
    } else {
      icon = <CheckCircle className="h-5 w-5 text-green-500" />;
      title = "Vous êtes dans les normes";
      message = `Vous n'avez utilisé que ${status.percentage.toFixed(0)}% de votre budget pour ${category}. Continuez comme ça!`;
    }
    
    return (
      <Alert variant={variant} className="mt-2">
        <div className="flex items-center">
          {icon}
          <AlertTitle className="ml-2">{title}</AlertTitle>
        </div>
        <AlertDescription className="mt-1">
          {message}
        </AlertDescription>
      </Alert>
    );
  };
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
    }).format(amount);
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold mb-4">Limites de dépenses mensuelles</h2>
        <p className="text-gray-500 mb-6">
          Définissez un budget mensuel pour chaque catégorie afin de suivre et gérer vos dépenses efficacement.
        </p>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {categories.map(category => {
          const spent = currentExpenses[category] || 0;
          const limit = parseFloat(limits[category]);
          const percentage = !isNaN(limit) && limit > 0 ? (spent / limit) * 100 : 0;
          const status = statuses[category] || { status: 'normal', percentage: 0 };
          
          return (
            <Card key={category} className="p-5">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium capitalize">{category}</h3>
                <div className="flex items-center space-x-2">
                  <Input
                    type="number"
                    value={limits[category]}
                    onChange={(e) => handleLimitChange(category, e.target.value)}
                    placeholder="Limite mensuelle"
                    className="w-32"
                  />
                  <Button onClick={() => handleSave(category)}>
                    Enregistrer
                  </Button>
                </div>
              </div>
              
              {!isNaN(limit) && limit > 0 && (
                <>
                  <div className="space-y-1 mb-2">
                    <div className="flex justify-between text-sm">
                      <span>Progression</span>
                      <span className={`font-medium ${status.status === 'danger' ? 'text-red-500' : status.status === 'warning' ? 'text-orange-500' : 'text-green-500'}`}>
                        {percentage.toFixed(0)}%
                      </span>
                    </div>
                    <Progress 
                      value={percentage} 
                      className="h-2" 
                      indicatorClassName={getStatusColor(status.status)}
                    />
                  </div>
                  
                  <div className="flex justify-between text-sm mb-4">
                    <div>
                      <span className="text-gray-500">Dépensé ce mois:</span>
                      <span className="ml-2 font-medium">{formatCurrency(spent)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Limite:</span>
                      <span className="ml-2 font-medium">{formatCurrency(limit)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Restant:</span>
                      <span className="ml-2 font-medium">{formatCurrency(Math.max(0, limit - spent))}</span>
                    </div>
                  </div>
                  
                  {getAdviceCard(category)}
                </>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default SpendingLimitsManager;
