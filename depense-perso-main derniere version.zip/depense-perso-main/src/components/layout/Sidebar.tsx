
import { Link, useLocation } from 'react-router-dom';
import { useExpenseStore } from '@/store/useExpenseStore';
import { cn } from '@/lib/utils';
import { 
  Home,
  PieChart,
  Target,
  BookOpen,
  Settings,
  Menu,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

const Sidebar = () => {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  
  const navItems = [
    { path: '/dashboard', label: 'Tableau de bord', icon: Home },
    { path: '/expenses', label: 'Dépenses', icon: PieChart },
    { path: '/goals', label: 'Objectifs', icon: Target },
    { path: '/education', label: 'Éducation', icon: BookOpen },
    { path: '/settings', label: 'Paramètres', icon: Settings },
  ];

  return (
    <>
      {/* Overlay pour mobile */}
      <div 
        className={cn(
          "fixed inset-0 z-20 bg-black/50 lg:hidden",
          collapsed ? "hidden" : "block"
        )}
        onClick={() => setCollapsed(true)}
      />
      
      {/* Bouton hamburger pour mobile */}
      <Button
        variant="outline"
        size="icon"
        className="fixed top-4 left-4 z-30 lg:hidden"
        onClick={() => setCollapsed(!collapsed)}
      >
        {collapsed ? <Menu /> : <X />}
      </Button>
      
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-20 w-64 bg-white shadow-lg transform transition-transform duration-200 lg:translate-x-0 lg:static lg:h-screen",
          collapsed ? "-translate-x-full" : "translate-x-0"
        )}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between h-16 px-4 border-b">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">T</div>
              <span className="text-xl font-bold text-blue-900">TrackEase</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setCollapsed(true)}
            >
              <X />
            </Button>
          </div>
          
          <nav className="flex-1 py-4 px-2 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center px-4 py-2 rounded-md transition-colors",
                  location.pathname === item.path
                    ? "bg-blue-100 text-blue-900"
                    : "text-gray-600 hover:bg-gray-100"
                )}
              >
                <item.icon className="mr-3 h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>
          
          <div className="p-4 border-t">
            <div className="text-sm text-gray-500 mb-2">
              Version 1.0
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
