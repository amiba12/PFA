
import { useNavigate } from 'react-router-dom';
import { useExpenseStore } from '@/store/useExpenseStore';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { LogOut, Plus } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const Header = () => {
  const logout = useExpenseStore((state) => state.logout);
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    toast({
      title: "Déconnexion réussie",
      description: "À bientôt sur TrackEase!",
    });
    navigate('/login');
  };
  
  const handleAddExpense = () => {
    navigate('/expenses/add');
  };

  return (
    <header className="bg-white border-b h-16 flex items-center justify-between px-4 lg:px-6">
      <div className="flex-1">
        <h1 className="text-xl font-semibold text-gray-800 md:block hidden">
          TrackEase
        </h1>
      </div>
      
      <div className="flex items-center gap-4">
        <Button 
          onClick={handleAddExpense} 
          size="sm" 
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="mr-1" />
          <span>Ajouter une dépense</span>
        </Button>
        
        <div className="flex items-center gap-2">
          <Avatar>
            <AvatarFallback className="bg-blue-200 text-blue-700">
              U
            </AvatarFallback>
          </Avatar>
          
          <Button variant="ghost" size="icon" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
