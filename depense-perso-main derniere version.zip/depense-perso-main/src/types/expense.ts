
export type ExpenseCategory = 
  | "nourriture" 
  | "transport" 
  | "loisirs" 
  | "logement" 
  | "santé" 
  | "éducation" 
  | "shopping" 
  | "factures" 
  | "autres";

export interface Expense {
  id: string;
  amount: number;
  description: string;
  category: ExpenseCategory;
  date: string; // format ISO
  createdAt: string; // format ISO
}

export interface SavingGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string; // format ISO
  createdAt: string; // format ISO
}

export interface ExpenseSummary {
  category: ExpenseCategory;
  total: number;
  count: number;
  average: number;
  percentage: number;
}

export interface MonthlyExpenseSummary {
  month: string; // format "YYYY-MM"
  total: number;
  categories: Record<ExpenseCategory, number>;
}
